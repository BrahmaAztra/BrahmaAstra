<?php 

/*******************************************************************************************************
 
 I created this script in order to show basic CRUDE operations to the HILIFE enterprises
 *******************************************************************/

 require_once 'header.php';
?>
<div class="container">
	<div class="jumbotron">
	<h1>Basic CRUD in PHP</h1>
	<p>Buenas adios mi amigos.</p>
</div>
</div>
<?php 

 require_once 'footer.php';